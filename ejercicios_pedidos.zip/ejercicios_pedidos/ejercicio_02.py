peso = float (input("introduzca peso en Kg..."))
altura= float (input("introduzca altura en m..."))
imc= peso/(altura*altura)
print (round(imc,2))
