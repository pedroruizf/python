animales=["perro","gato","oso","gorila","orangután"]
print (animales)
