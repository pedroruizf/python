c = float (input("introduzca temperatura en ºC..."))
f= 1.8*c+32
print ("la temperatura "+str(c)+" ºC"+" son "+str(round(f,2))+" ºF")

