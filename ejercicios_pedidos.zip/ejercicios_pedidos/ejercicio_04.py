numero = int (input("introduzca un número entero ..."))
resto= numero%2
if resto==0:
    print ("el numero "+str(numero)+" es par")
else:
    print ("el numero "+str(numero)+" es impar")


