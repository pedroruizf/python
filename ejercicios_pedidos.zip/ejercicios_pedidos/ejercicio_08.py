suma=0
for i in range (50,19,-2):
    suma=suma+i
print (suma)
    
