def mayor (numero1,numero2):
    if numero1>numero2:
        return numero1
    else:
        return numero2
    
num1=int(input("introduzca e numero 1..."))
num2=int(input("introduzca el numero 2..."))

print (mayor(num1,num2))
    
