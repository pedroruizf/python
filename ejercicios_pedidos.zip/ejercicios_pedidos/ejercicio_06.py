for i in range (1,26,2):
    print (i)
    
