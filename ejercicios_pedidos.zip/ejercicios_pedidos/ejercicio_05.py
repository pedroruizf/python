numero = int (input("introduzca un número entero ..."))

if numero>=10 and numero<=15:
    print ("el numero "+str(numero)+" está entre 10 y 15")
else:
    print ("el numero "+str(numero)+" no está entre 10 y 15")


