producto=1
for i in range (2,21,2):
    producto=producto*i
print (producto)
    
